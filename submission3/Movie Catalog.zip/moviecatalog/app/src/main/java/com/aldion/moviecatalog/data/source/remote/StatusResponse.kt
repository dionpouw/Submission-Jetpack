package com.aldion.moviecatalog.data.source.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}