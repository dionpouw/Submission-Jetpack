package com.aldion.moviecatalog.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}